
  # 3D Headphones Website (Community)

  This is a code bundle for 3D Headphones Website (Community). The original project is available at https://www.figma.com/design/s9jE6lebKQKlsxtc52Yj7r/3D-Headphones-Website--Community-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  